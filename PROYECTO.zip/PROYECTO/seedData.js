const { Product, sequelize } = require('./models');

const productosData = [
  { codigo: 'P001', nombre: 'Paracetamol 500mg x100 tab', descripcion: 'Analgésico y antipirético', precio: 15.00, stock: 45, stock_minimo: 10, fecha_vencimiento: '2026-12-31' },
  { codigo: 'P002', nombre: 'Ibuprofeno 400mg x100 tab', descripcion: 'Antiinflamatorio no esteroideo', precio: 20.00, stock: 8, stock_minimo: 10, fecha_vencimiento: '2026-10-15' },
  { codigo: 'P003', nombre: 'Amoxicilina 500mg x21 cap', descripcion: 'Antibiótico de amplio espectro', precio: 28.00, stock: 3, stock_minimo: 5, fecha_vencimiento: '2025-08-20' },
  { codigo: 'P004', nombre: 'Vitamina C 1000mg x30 tab', descripcion: 'Suplemento vitamínico', precio: 18.00, stock: 60, stock_minimo: 15, fecha_vencimiento: '2027-03-10' },
  { codigo: 'P005', nombre: 'Enalapril 10mg x60 tab', descripcion: 'Antihipertensivo inhibidor ECA', precio: 22.00, stock: 20, stock_minimo: 10, fecha_vencimiento: '2026-06-30' },
  { codigo: 'P006', nombre: 'Losartán 50mg x30 tab', descripcion: 'Antihipertensivo ARA II', precio: 25.00, stock: 4, stock_minimo: 8, fecha_vencimiento: '2026-09-15' },
  { codigo: 'P007', nombre: 'Omeprazol 20mg x30 cap', descripcion: 'Inhibidor de bomba de protones', precio: 16.00, stock: 35, stock_minimo: 10, fecha_vencimiento: '2026-11-20' },
  { codigo: 'P008', nombre: 'Alcohol 70° 1L', descripcion: 'Antiséptico para uso externo', precio: 9.00, stock: 2, stock_minimo: 10, fecha_vencimiento: '2027-01-01' },
  { codigo: 'P009', nombre: 'Metformina 850mg x60 tab', descripcion: 'Antidiabético biguanida', precio: 20.00, stock: 18, stock_minimo: 8, fecha_vencimiento: '2026-08-30' },
  { codigo: 'P010', nombre: 'Azitromicina 500mg x3 tab', descripcion: 'Antibiótico macrólido', precio: 35.00, stock: 6, stock_minimo: 5, fecha_vencimiento: '2026-04-15' },
  { codigo: 'P011', nombre: 'Vitamina D3 2000UI x60 cap', descripcion: 'Suplemento vitamínico', precio: 15.00, stock: 40, stock_minimo: 10, fecha_vencimiento: '2027-06-01' },
  { codigo: 'P012', nombre: 'Diclofenaco 50mg x30 tab', descripcion: 'Antiinflamatorio AINE', precio: 13.00, stock: 12, stock_minimo: 8, fecha_vencimiento: '2026-07-20' },
  { codigo: 'P013', nombre: 'Clonazepam 0.5mg x30 tab', descripcion: 'Ansiolítico benzodiazepínico', precio: 24.00, stock: 5, stock_minimo: 5, fecha_vencimiento: '2026-05-10' },
  { codigo: 'P014', nombre: 'Ranitidina 150mg x20 tab', descripcion: 'Antagonista H2 antiácido', precio: 11.00, stock: 1, stock_minimo: 10, fecha_vencimiento: '2025-12-31' },
  { codigo: 'P015', nombre: 'Betametasona Crema 0.05%', descripcion: 'Corticosteroide tópico', precio: 16.00, stock: 22, stock_minimo: 10, fecha_vencimiento: '2026-09-01' }
];

async function seed() {
  try {
    await sequelize.sync(); // Asegura que las tablas existan
    
    for (let p of productosData) {
      const existing = await Product.findOne({ where: { codigo: p.codigo } });
      if (!existing) {
        await Product.create(p);
      }
    }
    
    console.log('Productos de prueba agregados exitosamente.');
  } catch (error) {
    console.error('Error al poblar productos:', error);
  } finally {
    process.exit(0);
  }
}

seed();
