const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  const token = req.header('Authorization');
  if (!token) return res.status(401).json({ error: 'Acceso denegado, token no proporcionado.' });

  try {
    const verified = jwt.verify(token.replace('Bearer ', ''), 'secreto_super_seguro');
    req.user = verified;
    next();
  } catch (error) {
    res.status(400).json({ error: 'Token inválido' });
  }
};

const adminMiddleware = (req, res, next) => {
  if (req.user.rol !== 'admin') {
    return res.status(403).json({ error: 'Acceso denegado, se requiere rol de administrador.' });
  }
  next();
};

module.exports = { authMiddleware, adminMiddleware };
