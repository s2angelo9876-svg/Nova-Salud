const { Sale, SaleDetail, Product, sequelize } = require('../models');

exports.createSale = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const { items } = req.body; // array of { producto_id, cantidad, precio_unitario }
    let total = 0;

    // Calcular total y validar stock
    for (let item of items) {
      const producto = await Product.findByPk(item.producto_id, { transaction });
      if (!producto) {
        throw new Error(`Producto con ID ${item.producto_id} no encontrado`);
      }
      if (producto.stock < item.cantidad) {
        throw new Error(`Stock insuficiente para el producto ${producto.nombre}`);
      }
      total += item.cantidad * item.precio_unitario;
    }

    const sale = await Sale.create({
      total,
      usuario_id: req.user.id
    }, { transaction });

    for (let item of items) {
      await SaleDetail.create({
        venta_id: sale.id,
        producto_id: item.producto_id,
        cantidad: item.cantidad,
        precio_unitario: item.precio_unitario
      }, { transaction });

      // Update stock
      await Product.decrement('stock', {
        by: item.cantidad,
        where: { id: item.producto_id },
        transaction
      });
    }

    await transaction.commit();
    res.status(201).json({ message: 'Venta registrada con éxito', sale });
  } catch (error) {
    await transaction.rollback();
    res.status(400).json({ error: 'Error al registrar venta', detalles: error.message });
  }
};

exports.getSales = async (req, res) => {
  try {
    const sales = await Sale.findAll({
      include: [
        { model: require('../models/User'), attributes: ['nombre'] },
        { 
          model: SaleDetail, 
          include: [{ model: Product, attributes: ['nombre', 'codigo'] }] 
        }
      ],
      order: [['fecha', 'DESC']]
    });
    res.json(sales);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener ventas', detalles: error.message });
  }
};
