const { Product, sequelize } = require('../models');
const { Op } = require('sequelize');

exports.getAll = async (req, res) => {
  try {
    const productos = await Product.findAll();
    res.json(productos);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener productos', detalles: error.message });
  }
};

exports.getAlertas = async (req, res) => {
  try {
    const productos = await Product.findAll({
      where: {
        stock: {
          [Op.lte]: sequelize.col('stock_minimo')
        }
      }
    });
    res.json(productos);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener alertas', detalles: error.message });
  }
};

exports.create = async (req, res) => {
  try {
    const nuevoProducto = await Product.create(req.body);
    res.status(201).json(nuevoProducto);
  } catch (error) {
    res.status(400).json({ error: 'Error al crear producto', detalles: error.message });
  }
};

exports.getById = async (req, res) => {
  try {
    const producto = await Product.findByPk(req.params.id);
    if (!producto) return res.status(404).json({ error: 'Producto no encontrado' });
    res.json(producto);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener producto', detalles: error.message });
  }
};

exports.update = async (req, res) => {
  try {
    const producto = await Product.findByPk(req.params.id);
    if (!producto) return res.status(404).json({ error: 'Producto no encontrado' });
    
    await producto.update(req.body);
    res.json(producto);
  } catch (error) {
    res.status(400).json({ error: 'Error al actualizar producto', detalles: error.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const producto = await Product.findByPk(req.params.id);
    if (!producto) return res.status(404).json({ error: 'Producto no encontrado' });
    
    await producto.destroy();
    res.json({ message: 'Producto eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar producto', detalles: error.message });
  }
};
