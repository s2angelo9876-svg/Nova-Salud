const express = require('express');
const router = express.Router();
const ventasController = require('../controllers/ventasController');
const { authMiddleware } = require('../middlewares/auth');

router.post('/', authMiddleware, ventasController.createSale);
router.get('/', authMiddleware, ventasController.getSales);

module.exports = router;
