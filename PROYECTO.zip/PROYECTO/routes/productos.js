const express = require('express');
const router = express.Router();
const productosController = require('../controllers/productosController');
const { authMiddleware, adminMiddleware } = require('../middlewares/auth');

router.get('/', authMiddleware, productosController.getAll);
router.get('/alertas', authMiddleware, productosController.getAlertas);
router.post('/', [authMiddleware, adminMiddleware], productosController.create);
router.get('/:id', authMiddleware, productosController.getById);
router.put('/:id', [authMiddleware, adminMiddleware], productosController.update);
router.delete('/:id', [authMiddleware, adminMiddleware], productosController.delete);

module.exports = router;