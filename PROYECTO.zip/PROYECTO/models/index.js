const sequelize = require('../config/database');
const User = require('./User');
const Product = require('./Product');
const Sale = require('./Sale');
const SaleDetail = require('./SaleDetail');

// Associations
User.hasMany(Sale, { foreignKey: 'usuario_id' });
Sale.belongsTo(User, { foreignKey: 'usuario_id' });

Sale.hasMany(SaleDetail, { foreignKey: 'venta_id' });
SaleDetail.belongsTo(Sale, { foreignKey: 'venta_id' });

Product.hasMany(SaleDetail, { foreignKey: 'producto_id' });
SaleDetail.belongsTo(Product, { foreignKey: 'producto_id' });

module.exports = {
  sequelize,
  User,
  Product,
  Sale,
  SaleDetail
};
