const bcrypt = require('bcryptjs');
const { User, sequelize } = require('./models');

async function seed() {
  try {
    await sequelize.sync();
    const adminEmail = 'admin@novasalud.com';
    const passwordStr = 'admin123';
    
    const existing = await User.findOne({ where: { email: adminEmail } });
    if (!existing) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(passwordStr, salt);
      
      await User.create({
        nombre: 'Administrador Principal',
        email: adminEmail,
        password: hashedPassword,
        rol: 'admin'
      });
      console.log('Usuario administrador creado exitosamente.');
    } else {
      console.log('El usuario administrador ya existe.');
    }
  } catch (error) {
    console.error('Error al crear admin:', error);
  } finally {
    process.exit(0);
  }
}

seed();
