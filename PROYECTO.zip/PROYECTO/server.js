const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;
const morgan = require('morgan')
const cors = require('cors');
const { sequelize } = require('./models');

// Middleware para parsear JSON
app.use(express.json());
app.use(morgan('dev'))
app.use(cors())

// Importar rutas
const authRoutes = require('./routes/auth');
const productosRoutes = require('./routes/productos');
const ventasRoutes = require('./routes/ventas');

app.use('/api/auth', authRoutes);
app.use('/api/productos', productosRoutes);
app.use('/api/ventas', ventasRoutes);

// Sync Database and start server
sequelize.sync({ force: false }) // cambiar a true si quieres reiniciar la db en cada arranque
  .then(() => {
    console.log('Base de datos SQLite sincronizada');
    app.listen(PORT, () => {
      console.log(`Servidor corriendo en http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('Error al sincronizar la base de datos:', err);
  });
